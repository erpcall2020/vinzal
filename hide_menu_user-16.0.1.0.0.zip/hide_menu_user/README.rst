Hide Any Menu User Wise
=======================
* Hide Any Menu User Wise

Installation
============
	- www.odoo.com/documentation/16.0/setup/install.html
	- Install our custom addon

License
-------
General Public License, Version 3 (LGPL v3).
(https://www.odoo.com/documentation/user/16.0/legal/licenses/licenses.html)

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:
(v14) Sreerag @ Cybrosys
(v15) Midilaj @ Cybrosys
(v16) VISHNU KP @ Cybrosys


Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__

